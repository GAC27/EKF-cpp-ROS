# pioneer_2dnav
Pioneer3dx 2D navigation configuration and launch files

Use in combination with nav_bundle and pioneer_gazebo_ros for gazebo simulation

Use in combination with nav_bundle and pioneer_test for hardware implementation

NOTE: If using in combination with ESTOP package (https://github.com/nrjl/rqt_estop), uncomment line 9 to send cmd_vel via cmd_vel_estop
