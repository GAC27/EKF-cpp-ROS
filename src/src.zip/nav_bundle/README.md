# nav_bundle
nav bundle with roslaunch file calling:
- slam_gmapping
- move_base
- simple_navigation_goals
  - waypoint server/client nodes

NOTE: MAKE SURE TO CALL THE NAVIGATION PACKAGE RELEVANT TO YOUR ROBOT ON LINE 9 OR LINE 12.

For pioneer gazebo simulation or hardware use pioneer_2dnav.

For erratic stage robot simulation use stagebot_2dnav
